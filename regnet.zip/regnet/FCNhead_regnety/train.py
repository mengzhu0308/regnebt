#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2023/6/5 20:00
@File:          train.py
'''

import datetime
import os
import random
from copy import deepcopy
import numpy as np
import sys
import time
from pathlib import Path
import warnings
import presets
import segmentation_utils
import torch
from torch import nn
from torch.utils.data.dataloader import DataLoader
from torch.backends import cudnn
from Cityscapes import Cityscapes
from scheduler import PiecewiseLiner
from adamw import AdamW
from best2txt import best2txt
from trainhistory2X import trainhistory2txt, trainhistory2excel
from testhistory2X import testhistory2txt, testhistory2excel

from regnet import regnet_y_800mf

def get_transform(train):
    if train:
        return presets.SegmentationPresetTrain(base_size=520, crop_size=480)
    else:
        return presets.SegmentationPresetEval(base_size=520)

def criterion(inputs, target):
    '''
    cityscapes语义标注，255表示背景处像素
    '''
    target = torch.where(torch.ne(target, 255), target, 19) # 将255转换成19，纳入损失函数计算
    losses = {}
    for name, x in inputs.items():
        losses[name] = nn.functional.cross_entropy(x, target)

    if len(losses) == 1:
        return losses["out"]

    return losses["out"] + 0.5 * losses["aux"]

def evaluate(model, data_loader, device, num_classes):
    model.eval()
    confmat = segmentation_utils.ConfusionMatrix(num_classes)
    metric_logger = segmentation_utils.MetricLogger(delimiter="  ")
    header = "Test:"
    num_processed_samples = 0
    total_loss = 0
    with torch.inference_mode():
        for image, target in metric_logger.log_every(data_loader, header):
            image, target = image.to(device), target.to(device)
            output = model(image)
            loss = criterion(output, target)
            output = output["out"]

            confmat.update(target.flatten(), output.argmax(1).flatten())
            # FIXME need to take into account that the datasets
            # could have been padded in distributed setup
            num_processed_samples += image.shape[0]

            total_loss += loss.item()

        confmat.reduce_from_all_processes()

    num_processed_samples = segmentation_utils.reduce_across_processes(num_processed_samples)
    if (
        hasattr(data_loader.dataset, "__len__")
        and len(data_loader.dataset) != num_processed_samples
        and torch.distributed.get_rank() == 0
    ):
        # See FIXME above
        warnings.warn(
            f"It looks like the dataset has {len(data_loader.dataset)} samples, but {num_processed_samples} "
            "samples were used for the validation, which might bias the results. "
            "Try adjusting the batch size and / or the world size. "
            "Setting the world size to 1 is always a safe bet."
        )

    return confmat, total_loss / len(data_loader)

def train_one_epoch(model, criterion, optimizer, data_loader, device, epoch, hist=None):
    model.train()
    metric_logger = segmentation_utils.MetricLogger(delimiter="  ")
    header = f"Epoch: [{epoch + 1}]"
    total_loss = 0
    for image, target in metric_logger.log_every(data_loader, header):
        image, target = image.to(device), target.to(device)
        output = model(image)
        loss = criterion(output, target)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        metric_logger.update(loss=loss.item())

        if hist is not None:
            hist["loss"].append(loss.item())

    return total_loss / len(data_loader)

def create_dir(*dirs):
    for dir in dirs:
        dir_path = Path(dir)
        if not dir_path.exists():
            dir_path.mkdir(parents=True)
            print(f'create the dir: "{dir_path.as_posix()}"')
        else:
            print(f'The dir "{dir_path.as_posix()}" existed')

'''
固定随机种子，让结果可复现
'''
def init_seeds(seed=42):
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        if seed is not None:  # slower, more reproducible
            cudnn.deterministic = True
            cudnn.benchmark = False
        else:  # faster, less reproducible
            cudnn.deterministic = False
            cudnn.benchmark = True

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
init_seeds(seed=42)

if __name__ == '__main__':
    if torch.cuda.is_available():
        device = torch.device('cuda')
        pin_memory = True
    else:
        device = torch.device('cpu')
        pin_memory = False

    batch_size = 32
    workers = 0
    num_classes = 19 + 1

    dataset = Cityscapes("/media/zm/zm1/datasets/cityscapes", split='train', target_type="semantic",
                         transforms=get_transform(True))
    dataset_test = Cityscapes("/media/zm/zm1/datasets/cityscapes", split='val', target_type="semantic",
                              transforms=get_transform(False))

    train_sampler = torch.utils.data.RandomSampler(dataset)
    test_sampler = torch.utils.data.SequentialSampler(dataset_test)
    data_loader = DataLoader(
        dataset,
        batch_size=batch_size,
        sampler=train_sampler,
        num_workers=workers,
        collate_fn=segmentation_utils.collate_fn,
        drop_last=True,
        pin_memory=pin_memory
    )

    data_loader_test = DataLoader(
        dataset_test, batch_size=1, sampler=test_sampler, num_workers=workers,
        collate_fn=segmentation_utils.collate_fn,
        pin_memory=pin_memory
    )

    model = regnet_y_800mf(num_classes=num_classes)
    model.to(device)
    torch.compile(model)

    init_lr = 2e-3 * max(1., batch_size / 256)
    iters_per_epoch = len(data_loader)
    scheduler = PiecewiseLiner(schedule={iters_per_epoch: None, 27 * iters_per_epoch: 0.01}, from_zero=True)
    optimizer = AdamW(model.parameters(), lr=init_lr, scheduler=scheduler, weight_decay=0.)

    opt_name = 'Adam'
    if len(sys.argv) == 2:
        dir = sys.argv[1]
        weights_dir = f'{dir}/weights_{opt_name}'
        txt_dir = f'{dir}/txts_{opt_name}'
        excel_dir = f'{dir}/excel_{opt_name}'
    else:
        weights_dir = f'weights_{opt_name}'
        txt_dir = f'txts_{opt_name}'
        excel_dir = f'excel_{opt_name}'

    create_dir(weights_dir, txt_dir, excel_dir)


    pa_best_rsts = {'loss': np.Inf, 'val_loss': np.Inf, 'pa': 0, 'miou': 0}
    miou_best_rsts = {'loss': np.Inf, 'val_loss': np.Inf, 'pa': 0, 'miou': 0}
    miou_best_wts = model.state_dict()
    train_hist = {"loss": []}
    test_hist = {"val_loss": [], "pa": [], "miou": []}

    start_time = time.time()
    epochs = 40
    for epoch in range(epochs):
        loss = train_one_epoch(model, criterion, optimizer, data_loader, device, epoch, hist=train_hist)
        confmat, val_loss = evaluate(model, data_loader_test, device=device, num_classes=num_classes)
        print(confmat)

        if pa_best_rsts['pa'] < confmat.metrics['pa']:
            pa_best_rsts['pa'] = confmat.metrics['pa']
            pa_best_rsts['miou'] = confmat.metrics['miou']
            pa_best_rsts['loss'] = loss
            pa_best_rsts['val_loss'] = val_loss

        if miou_best_rsts['miou'] < confmat.metrics['miou']:
            miou_best_rsts['miou'] = confmat.metrics['miou']
            miou_best_rsts['pa'] = confmat.metrics['pa']
            miou_best_rsts['loss'] = loss
            miou_best_rsts['val_loss'] = val_loss
            miou_best_wts = deepcopy(model.state_dict())

        test_hist["val_loss"].append(val_loss)
        test_hist["pa"].append(confmat.metrics["pa"])
        test_hist["miou"].append(confmat.metrics["miou"])

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print(f"Training time {total_time_str}")

    model_name = 'regnet_y_800mf'
    dataset_name = 'cityscapes'
    metric_name = 'miou'
    model.load_state_dict(miou_best_wts)
    torch.save(model.state_dict(), f'{weights_dir}/{model_name}_weights_{dataset_name}_{metric_name}.pt')

    metric_name = 'miou'
    str_best_rsts = (f'loss: {miou_best_rsts["loss"]}, val_loss: {miou_best_rsts["val_loss"]}\n'
                     f'pa: {miou_best_rsts["pa"]}, miou: {miou_best_rsts["miou"]}')
    best2txt(str_best_rsts, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name,
             metric_name=metric_name)

    metric_name = 'pa'
    str_best_rsts = (f'loss: {pa_best_rsts["loss"]}, val_loss: {pa_best_rsts["val_loss"]}\n'
                     f'pa: {pa_best_rsts["pa"]}, miou: {pa_best_rsts["miou"]}')
    best2txt(str_best_rsts, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name,
             metric_name=metric_name)

    trainhistory2excel(train_hist, saved_dir=excel_dir, model_name=model_name, dataset_name=dataset_name)
    trainhistory2txt(train_hist, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name)
    testhistory2excel(test_hist, saved_dir=excel_dir, model_name=model_name, dataset_name=dataset_name)
    testhistory2txt(test_hist, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name)