#!/bin/bash

source ~/anaconda3/etc/profile.d/conda.sh

conda activate pt
python cifar_regnet_x_400mf/train_cifar100.py cifar_regnet_x_400mf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_x_800mf/train_cifar100.py cifar_regnet_x_800mf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_x_1_6gf/train_cifar100.py cifar_regnet_x_1_6gf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_x_3_2gf/train_cifar100.py cifar_regnet_x_3_2gf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_x_8gf/train_cifar100.py cifar_regnet_x_8gf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_x_16gf/train_cifar100.py cifar_regnet_x_16gf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_y_400mf/train_cifar100.py cifar_regnet_y_400mf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_y_800mf/train_cifar100.py cifar_regnet_y_800mf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_y_1_6gf/train_cifar100.py cifar_regnet_y_1_6gf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_y_3_2gf/train_cifar100.py cifar_regnet_y_3_2gf
conda deactivate
sleep 240s

conda activate pt
python cifar_regnet_y_8gf/train_cifar100.py cifar_regnet_y_8gf
conda deactivate
sleep 240s

conda activate pt
python yolov7head_regnetx/train.py yolov7head_regnetx
conda deactivate
sleep 240s

conda activate pt
python FCNhead_regnetx/train.py FCNhead_regnetx
conda deactivate
sleep 240s

sleep 240s
shutdown -P now
