#! -*- coding:utf-8 -*-

'''
@Author:        zm
@Date and Time: 2019/8/16 17:05
@File:          ImageToTensor.py
'''

import torch

class ImageToTensor:
    def __call__(self, image):
        return torch.from_numpy(image.transpose(2, 0, 1))