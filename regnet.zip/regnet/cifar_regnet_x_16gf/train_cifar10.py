#! -*- coding:utf-8 -*-

'''
@Author:        zm
@Date and Time: 2019/9/20 6:44
@File:          train_cifar100.py
'''

import os
import random
import sys
from pathlib import Path
import math
import numpy as np
from copy import deepcopy
import torch
from torch.nn.modules.loss import CrossEntropyLoss
from scheduler import PiecewiseLiner
from adamw import AdamW
from torch.utils.data.dataloader import DataLoader
from torch.backends import cudnn
from torchvision.transforms.transforms import Compose

from ConvertImageDtype import ConvertImageDtype
from RandomHorizontalFlip import RandomHorizontalFlip
from ImageToTensor import ImageToTensor
from TargetToTensor import TargetToTensor
from Normalization import Normalization
from RandomRGB2HSV import RandomRGB2HSV
from cifar_dataset import get_cifar10
from MyDataset import MyDataset
from best2txt import best2txt
from regnet import regnet_y_800mf
from trainhistory2X import trainhistory2txt, trainhistory2excel
from testhistory2X import testhistory2txt, testhistory2excel

def create_dir(*dirs):
    for dir in dirs:
        dir_path = Path(dir)
        if not dir_path.exists():
            dir_path.mkdir(parents=True)
            print(f'create the dir: "{dir_path.as_posix()}"')
        else:
            print(f'The dir "{dir_path.as_posix()}" existed')

def init_seeds(seed=42):
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        if seed is not None:  # slower, more reproducible
            cudnn.deterministic = True
            cudnn.benchmark = False
        else:  # faster, less reproducible
            cudnn.deterministic = False
            cudnn.benchmark = True

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
init_seeds(seed=42)

if __name__ == '__main__':
    if torch.cuda.is_available():
        device = torch.device('cuda')
        pin_memory = True
    else:
        device = torch.device('cpu')
        pin_memory = False

    train_batch_size = 128
    val_batch_size = 200
    init_lr = 2e-3 * max(1., train_batch_size / 256)
    epochs = 80
    num_classes = 10
    space = '  '

    opt_name = 'Adam'
    if len(sys.argv) == 2:
        dir = sys.argv[1]
        weights_dir = f'{dir}/weights_{opt_name}'
        txt_dir = f'{dir}/txts_{opt_name}'
        excel_dir = f'{dir}/excel_{opt_name}'
    else:
        weights_dir = f'weights_{opt_name}'
        txt_dir = f'txts_{opt_name}'
        excel_dir = f'excel_{opt_name}'

    model_name = 'regnet_y_800mf'
    dataset_name = 'cifar10'

    create_dir(weights_dir, txt_dir, excel_dir)

    convert_image_dtype = ConvertImageDtype()
    norm = Normalization()
    image_to_tensor = ImageToTensor()
    train_transform = Compose([
        convert_image_dtype,
        RandomRGB2HSV(),
        RandomHorizontalFlip(),
        norm,
        image_to_tensor
    ])
    val_transform = Compose([
        convert_image_dtype,
        norm,
        image_to_tensor
    ])
    label_transform = TargetToTensor()

    (X_train, Y_train), (X_val, Y_val) = get_cifar10()
    Y_train = Y_train.astype(np.int64)
    Y_val = Y_val.astype(np.int64)
    train_dataset = MyDataset(X_train, y=Y_train, transform=train_transform, y_transform=label_transform)
    val_dataset = MyDataset(X_val, y=Y_val, transform=val_transform, y_transform=label_transform)
    train_dataloader = DataLoader(train_dataset, batch_size=train_batch_size, shuffle=True, pin_memory=pin_memory,
                                  drop_last=True, num_workers=0)
    val_dataloader = DataLoader(val_dataset, batch_size=val_batch_size, shuffle=False, pin_memory=pin_memory,
                                drop_last=False, num_workers=0)

    model = regnet_y_800mf(num_classes=num_classes).to(device)
    torch.compile(model)
    iters_per_epoch = len(train_dataloader)
    scheduler = PiecewiseLiner(schedule={iters_per_epoch: None, 55 * iters_per_epoch: 0.01}, from_zero=True)
    optimizer = AdamW(model.parameters(), lr=init_lr, scheduler=scheduler, weight_decay=0.)
    criterion = CrossEntropyLoss().to(device)

    num_train_batches = len(train_dataloader)
    num_train_examples = num_train_batches * train_batch_size

    train_hist = {"loss": []}
    val_hist = {"val_loss": [], "top1_err": [], "top5_err": []}

    def train():
        total_loss = 0.

        model.train()
        for i_batch, (x, y_true) in enumerate(train_dataloader):
            x, y_true = x.to(device), y_true.to(device)
            y_pred = model(x)
            loss = criterion(y_pred, y_true)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            loss_item = loss.item()
            if math.isnan(loss_item) or math.isinf(loss_item):
                print('nan or inf')
                break

            pbar_len = 20
            pbar_run = pbar_len * (i_batch + 1) // num_train_batches
            pbar_left = pbar_run * '='
            pbar_right = (pbar_len - pbar_run) * ' '
            begin_s = f'{i_batch + 1}/{num_train_batches}{space}[{pbar_left}{pbar_right}]'
            log_s = f'loss: {loss_item:.5f}'
            end_s = '\n' if i_batch + 1 >= num_train_batches else ''
            sys.stdout.write(f'\r{begin_s}{space}{log_s}{end_s}')
            sys.stdout.flush()

            total_loss += loss.item()
            train_hist["loss"].append(loss.item())

        return total_loss / num_train_batches

    num_val_batches = len(val_dataloader)
    # num_val_examples = num_val_batches * val_batch_size
    num_val_examples = len(val_dataset)

    def val():
        total_loss = 0.
        top1_total_corrects = 0
        top5_total_corrects = 0

        model.eval()
        with torch.no_grad():
            for x, y_true in val_dataloader:
                x, y_true = x.to(device), y_true.to(device)
                y_pred = model(x)
                loss = criterion(y_pred, y_true)

                loss_item = loss.item()
                if math.isnan(loss_item) or math.isinf(loss_item):
                    print('nan or inf')
                    break

                total_loss += loss.item() * x.size(0)

                '''
                评估指标
                '''
                _, top5_pred = torch.topk(y_pred, 5)
                top1_total_corrects += torch.sum((top5_pred[:, 0] == y_true).int()).item()
                top5_total_corrects += torch.sum((top5_pred == y_true.unsqueeze(1)).int()).item()
        '''
        评估指标
        '''
        top1_err = (1 - top1_total_corrects / num_val_examples) * 100.0
        top5_err = (1 - top5_total_corrects / num_val_examples) * 100.0

        return total_loss / num_val_examples, top1_err, top5_err


    top1_best_rsts = {'loss': np.Inf, 'val_loss': np.Inf, 'top1_err': 100., 'top5_err': 100.}
    top5_best_rsts = {'loss': np.Inf, 'val_loss': np.Inf, 'top1_err': 100., 'top5_err': 100.}
    top1_best_wts = model.state_dict()

    print(f'Train on {len(train_dataset)} samples with train_batch_size equalling {train_batch_size}. '
          f'Val on {len(val_dataset)} samples with val_batch_size equalling {val_batch_size}.')
    print(f'init_lr eualling {init_lr}')

    for i_epoch in range(epochs):
        print(f'Epoch {i_epoch + 1}/{epochs}')

        loss = train()
        val_loss, top1_err, top5_err = val()
        val_hist["val_loss"].append(val_loss)
        val_hist["top1_err"].append(top1_err)
        val_hist["top5_err"].append(top5_err)

        if (math.isnan(loss) or math.isinf(loss) or
                math.isnan(val_loss) or math.isinf(val_loss)):
            print('nan or inf')
            break

        print(f'loss: {loss:.5f}{space}val_loss: {val_loss:.5f}{space}top-1 error: {top1_err:.2f}{space}top-5 error: {top5_err:.2f}{space}')

        if top1_best_rsts['top1_err'] > top1_err:
            top1_best_rsts['loss'], top1_best_rsts['val_loss'] = loss, val_loss
            top1_best_rsts['top1_err'], top1_best_rsts['top5_err'] = top1_err, top5_err
            top1_best_wts = deepcopy(model.state_dict())

        if top5_best_rsts['top5_err'] > top5_err:
            top5_best_rsts['loss'], top5_best_rsts['val_loss'] = loss, val_loss
            top5_best_rsts['top1_err'], top5_best_rsts['top5_err'] = top1_err, top5_err

    metric_name = 'top1-err'
    model.load_state_dict(top1_best_wts)
    torch.save(model.state_dict(), f'{weights_dir}/{model_name}_weights_{dataset_name}_{metric_name}.pt')

    metric_name = 'top1-err'
    str_best_rsts = (f'loss: {top1_best_rsts["loss"]}, val_loss: {top1_best_rsts["val_loss"]}\n'
                     f'top-1 error: {top1_best_rsts["top1_err"]}, top-5 error: {top1_best_rsts["top5_err"]}')
    best2txt(str_best_rsts, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name,
             metric_name=metric_name)

    metric_name = 'top5-err'
    str_best_rsts = (f'loss: {top5_best_rsts["loss"]}, val_loss: {top5_best_rsts["val_loss"]}\n'
                     f'top-1 error: {top5_best_rsts["top1_err"]}, top-5 error: {top5_best_rsts["top5_err"]}')
    best2txt(str_best_rsts, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name,
             metric_name=metric_name)

    trainhistory2excel(train_hist, saved_dir=excel_dir, model_name=model_name, dataset_name=dataset_name)
    trainhistory2txt(train_hist, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name)
    testhistory2excel(val_hist, saved_dir=excel_dir, model_name=model_name, dataset_name=dataset_name)
    testhistory2txt(val_hist, saved_dir=txt_dir, model_name=model_name, dataset_name=dataset_name)