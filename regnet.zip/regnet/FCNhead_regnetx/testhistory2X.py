'''
@Author:        zm
@Date and Time: 2019/8/8 18:20
@File:          testhistory2X.py
'''

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def testhistory2png(hist, saved_dir='.', model_name='', dataset_name=''):
    val_loss = np.array(hist['val_loss'], dtype=np.float32)
    pa = np.array(hist['pa'], dtype=np.float32)
    miou = np.array(hist['miou'], dtype=np.float32)

    # Plot validation metric values
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(pa)
    ax.grid(True)
    ax.set(ylabel='pa', xlabel='epoch')
    fig.savefig(f'{saved_dir}/{model_name}_{dataset_name}_test_pa.pdf')

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(miou)
    ax.grid(True)
    ax.set(ylabel='miou', xlabel='epoch')
    fig.savefig(f'{saved_dir}/{model_name}_{dataset_name}_test_miou.pdf')

    # Plot training & validation loss values
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(val_loss)
    ax.legend()
    ax.grid(True)
    ax.set(ylabel='loss', xlabel='epoch')
    fig.savefig(f'{saved_dir}/{model_name}_{dataset_name}_test_loss.pdf')

def testhistory2excel(hist, saved_dir='.', model_name='', dataset_name=''):
    val_loss = np.array(hist['val_loss'], dtype=np.float32)
    pa = np.array(hist['pa'], dtype=np.float32)
    miou = np.array(hist['miou'], dtype=np.float32)

    df = pd.DataFrame({"val_loss": val_loss, "pa": pa, "miou": miou})

    df.to_excel(f'{saved_dir}/{model_name}_{dataset_name}_test_hist.xlsx', sheet_name='History', index=False)

def testhistory2txt(hist, saved_dir='.', model_name='', dataset_name=''):
    val_loss = np.array(hist['val_loss'], dtype=np.float32)
    pa = np.array(hist['pa'], dtype=np.float32)
    miou = np.array(hist['miou'], dtype=np.float32)

    lines = []
    line = 'val_loss\tpa\tmiou\n'
    lines.append(line)
    for i, l in enumerate(val_loss):
        line = f'{l:.5f}\t{pa[i]:.2f}\t{miou[i]:.2f}\n'
        lines.append(line)

    lines[-1] = lines[-1].strip()
    with open(f'{saved_dir}/{model_name}_{dataset_name}_test_hist.txt', 'w', encoding='utf-8') as f:
        f.writelines(lines)