#!/bin/bash

source ~/anaconda3/etc/profile.d/conda.sh

conda activate pt
python cifar_efficientnet_b0/train_cifar100.py cifar_efficientnet_b0
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnet_b1/train_cifar100.py cifar_efficientnet_b1
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnet_b2/train_cifar100.py cifar_efficientnet_b2
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnet_b3/train_cifar100.py cifar_efficientnet_b3
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnet_b4/train_cifar100.py cifar_efficientnet_b4
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnet_b5/train_cifar100.py cifar_efficientnet_b5
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnet_b6/train_cifar100.py cifar_efficientnet_b6
conda deactivate
sleep 240s

conda activate pt
python yolov7head_efficientnet/train.py yolov7head_efficientnet
conda deactivate
sleep 240s

conda activate pt
python FCNhead_efficientnet/train.py FCNhead_efficientnet
conda deactivate
sleep 240s

sleep 240s
shutdown -P now
