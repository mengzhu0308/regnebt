#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2020/12/15 14:15
@File:          best2txt.py
'''

def best2txt(best_rst, saved_dir='.', model_name='', dataset_name='', metric_name=''):
    with open(f'{saved_dir}/{model_name}_{dataset_name}_{metric_name}_best.txt', 'w', encoding='utf-8') as f:
        f.writelines(best_rst.strip())