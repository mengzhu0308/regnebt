#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2024/1/9 8:08
@File:          eval.py
'''

from typing import Any
import os
import xml.etree.ElementTree as ET
from pathlib import Path
from PIL import Image
from tqdm import tqdm
from yolo_predict import YOLO
from model_data.VOCData import VOCData
from utils.map_utils import get_map, get_coco_map


voc_data = VOCData()
class_names = voc_data.classes


def get_ground_truth_result(annotations_dir: str = "/media/zm/zm1/datasets/voc/VOC2007test/Annotations", map_out_path: str = "logs/map_out"):
    if not os.path.exists(map_out_path):
        os.makedirs(map_out_path)
    if not os.path.exists(os.path.join(map_out_path, 'ground-truth')):
        os.makedirs(os.path.join(map_out_path, 'ground-truth'))

    annotations = Path(annotations_dir).glob("*.xml")

    print("Get ground truth result.")
    for annotation in tqdm(annotations):
        image_id = annotation.stem
        with open(os.path.join(map_out_path, "ground-truth/" + image_id + ".txt"), "w") as new_f:
            root = ET.parse(annotation.as_posix()).getroot()
            for obj in root.findall('object'):
                difficult_flag = False
                if obj.find('difficult') != None:
                    difficult = obj.find('difficult').text
                    if int(difficult) == 1:
                        difficult_flag = True
                obj_name = obj.find('name').text
                if obj_name not in class_names:
                    continue
                bndbox = obj.find('bndbox')
                left = bndbox.find('xmin').text
                top = bndbox.find('ymin').text
                right = bndbox.find('xmax').text
                bottom = bndbox.find('ymax').text

                if difficult_flag:
                    new_f.write("%s %s %s %s %s difficult\n" % (obj_name, left, top, right, bottom))
                else:
                    new_f.write("%s %s %s %s %s\n" % (obj_name, left, top, right, bottom))
    print("Get ground truth result done.")


def eval(yolo: YOLO,
         images_dir: str = "/media/zm/zm1/datasets/voc/VOC2007test/JPEGImages",
         map_out_path: str = 'logs/map_out',
         map_mode: str = "voc",
         MINOVERLAP: float = 0.5,
         score_threhold: float = 0.5,
         map_vis: bool = False) -> Any:
    '''
    :param images_dir: 评估图片所在的目录
    :param map_out_path: 结果输出的文件夹
    :param map_mode:
    #   map_mode为"voc"代表计算VOC_map。
    #   map_mode为"coco"代表利用COCO工具箱计算当前数据集的0.50:0.95map。需要获得预测结果、获得真实框后并安装pycocotools才行
    :param MINOVERLAP:
    #   MINOVERLAP用于指定想要获得的mAP0.x，mAP0.x的意义是什么请同学们百度一下。
    #   比如计算mAP0.75，可以设定MINOVERLAP = 0.75。
    #   当某一预测框与真实框重合度大于MINOVERLAP时，该预测框被认为是正样本，否则为负样本。
    #   因此MINOVERLAP的值越大，预测框要预测的越准确才能被认为是正样本，此时算出来的mAP值越低.
    :param score_threhold:
    #   Recall和Precision不像AP是一个面积的概念，因此在门限值不同时，网络的Recall和Precision值是不同的。
    #   默认情况下，本代码计算的Recall和Precision代表的是当门限值为0.5（此处定义为score_threhold）时所对应的Recall和Precision值。
    #   因为计算mAP需要获得近乎所有的预测框，上面定义的confidence不能随便更改。
    #   这里专门定义一个score_threhold用于代表门限值，进而在计算mAP时找到门限值对应的Recall和Precision值。
    :param map_vis:
    #   map_vis用于指定是否开启VOC_map计算的可视化
    :return:

    Recall和Precision不像AP是一个面积的概念，因此在门限值（Confidence）不同时，网络的Recall和Precision值是不同的。
    默认情况下，本代码计算的Recall和Precision代表的是当门限值（Confidence）为0.5时，所对应的Recall和Precision值。
    受到mAP计算原理的限制，网络在计算mAP时需要获得近乎所有的预测框，这样才可以计算不同门限条件下的Recall和Precision值
    因此，本代码获得的map_out/detection-results/里面的txt的框的数量一般会比直接predict多一些，目的是列出所有可能的预测框。
    '''

    if not os.path.exists(map_out_path):
        os.makedirs(map_out_path)
    if not os.path.exists(os.path.join(map_out_path, 'ground-truth')):
        os.makedirs(os.path.join(map_out_path, 'ground-truth'))
    if not os.path.exists(os.path.join(map_out_path, 'detection-results')):
        os.makedirs(os.path.join(map_out_path, 'detection-results'))
    if not os.path.exists(os.path.join(map_out_path, 'images-optional')):
        os.makedirs(os.path.join(map_out_path, 'images-optional'))

    image_paths = Path(images_dir).glob("*.jpg")

    print("Get predict result.")
    for image_path in tqdm(image_paths):
        image = Image.open(image_path.as_posix())
        image_id = image_path.stem
        if map_vis:
            image.save(os.path.join(map_out_path, "images-optional/" + image_id + ".jpg"))
        yolo.get_map_txt(image_id, image, class_names, map_out_path)
    print("Get predict result done.")

    if map_mode == "voc":
        print("Get map.")
        mAP = get_map(MINOVERLAP, True, score_threhold=score_threhold, path=map_out_path)
        print("Get map done.")
        return mAP
    else:
        print("Get map.")
        stats = get_coco_map(class_names=class_names, path=map_out_path)
        print("Get map done.")
        return stats