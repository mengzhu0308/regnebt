#!/bin/bash

source ~/anaconda3/etc/profile.d/conda.sh

conda activate pt
python cifar_regnebt_b0_q2/train_cifar100.py cifar_regnebt_b0_q2
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b1_q2/train_cifar100.py cifar_regnebt_b1_q2
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b1_q3/train_cifar100.py cifar_regnebt_b1_q3
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b1_q4/train_cifar100.py cifar_regnebt_b1_q4
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b2_q2/train_cifar100.py cifar_regnebt_b2_q2
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b3_q2/train_cifar100.py cifar_regnebt_b3_q2
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b4_q2/train_cifar100.py cifar_regnebt_b4_q2
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b5_q2/train_cifar100.py cifar_regnebt_b5_q2
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b4_q3/train_cifar100.py cifar_regnebt_b4_q3
conda deactivate
sleep 240s

conda activate pt
python cifar_regnebt_b4_q4/train_cifar100.py cifar_regnebt_b4_q4
conda deactivate
sleep 240s

conda activate pt
python yolov7head_regnebt/train.py yolov7head_regnebt
conda deactivate
sleep 240s

conda activate pt
python FCNhead_regnebt/train.py FCNhead_regnebt
conda deactivate
sleep 240s

sleep 240s
shutdown -P now
