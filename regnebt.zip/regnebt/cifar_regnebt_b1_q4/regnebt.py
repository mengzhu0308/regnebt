#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2024/4/9 19:24
@File:          regnebt.py
'''

from typing import Callable, Any, Tuple, List, TypeVar
from collections import OrderedDict
from functools import partial
from torch import Tensor
import math
import random
import numpy as np
import torch
from torch import nn

from utils import _log_api_usage_once, _make_divisible


M = TypeVar("M", bound=nn.Module)
BUILTIN_MODELS = {}


def register_model(name: str | None = None) -> Callable[[Callable[..., M]], Callable[..., M]]:
    def wrapper(fn: Callable[..., M]) -> Callable[..., M]:
        key = name if name is not None else fn.__name__
        if key in BUILTIN_MODELS:
            raise ValueError(f"An entry is already registered under the name '{key}'.")
        BUILTIN_MODELS[key] = fn
        return fn

    return wrapper


class EfficientBranchAttn(nn.Module):
    def __init__(self, units: int,
                 branches: int) -> None:
        assert units % branches == 0
        super().__init__()

        self.branches = branches

        self.conv1 = nn.Conv1d(1, 1, 7, padding=3, bias=False)
        self.conv2 = nn.Conv1d(1, branches, 7, padding=3, bias=False)

    def forward(self, inputs: Tensor) -> Tensor:
        N, C, H, W = inputs.size()

        mu = torch.mean(inputs, (-2, -1)).unsqueeze(1)
        s1 = self.conv1(mu).view(N, self.branches, C // self.branches)

        x = inputs.view(N, self.branches, C // self.branches, H, W)
        z = torch.sum(x, 1, keepdim=True)
        mu = torch.mean(z, (-2, -1))
        s2 = self.conv2(mu)

        if self.training:
            lamb = random.uniform(0, 1.)
            attn_scores = s1 * lamb + s2 * (1 - lamb)
        else:
            attn_scores = (s1 + s2) / 2

        a = torch.softmax(attn_scores, 1)
        a = a.unsqueeze(-1).unsqueeze(-1)

        o = torch.sum(x * a, 1)
        return o


class SimpleStemIn(nn.Sequential):
    def __init__(self, in_units: int,
                 out_units: int,
                 stride: int | Tuple[int, int] | List[int] = 2,
                 conv_layer: Callable[..., nn.Module] | None = None,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        if conv_layer is None:
            conv_layer = partial(nn.Conv2d, bias=False)
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = nn.SiLU

        layers = [
            conv_layer(in_units, out_units, 3, stride=stride, padding=1),
            norm_layer(out_units),
            activation_layer()
        ]

        super().__init__(*layers)


class InvertedBottleneck(nn.Sequential):
    def __init__(self, in_units: int,
                 out_units: int,
                 stride: int,
                 branches: int,
                 conv_layer: Callable[..., nn.Module],
                 norm_layer: Callable[..., nn.Module],
                 activation_layer: Callable[..., nn.Module]) -> None:
        assert in_units % branches == 0
        hidden_units = out_units * branches
        layers = [
            conv_layer(in_units, hidden_units, 1, groups=branches),
            norm_layer(hidden_units),
            activation_layer(),
            conv_layer(hidden_units, hidden_units, 3, stride=stride, padding=1, groups=hidden_units),
            norm_layer(hidden_units),
            activation_layer(),
            EfficientBranchAttn(hidden_units, branches),
            conv_layer(out_units, out_units, 1),
            norm_layer(out_units)
        ]
        super().__init__(*layers)


class Residual(nn.Module):
    def __init__(self, in_units: int,
                 out_units: int,
                 branches: int,
                 conv_layer: Callable[..., nn.Module] | None = None,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        assert in_units == out_units
        if conv_layer is None:
            conv_layer = partial(nn.Conv2d, bias=False)
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = nn.SiLU
        super().__init__()

        self.block = InvertedBottleneck(in_units, out_units, 1, branches, conv_layer, norm_layer, activation_layer)

    def forward(self, inputs: Tensor) -> Tensor:
        return inputs + self.block(inputs)


class AnyStage(nn.Sequential):
    def __init__(self, in_units: int,
                 out_units: int,
                 stride: int,
                 branches: int,
                 depth: int,
                 conv_layer: Callable[..., nn.Module],
                 norm_layer: Callable[..., nn.Module],
                 activation_layer: Callable[..., nn.Module],
                 stage_index: int = 0) -> None:
        factory_kwargs = {"conv_layer": conv_layer, "norm_layer": norm_layer, "activation_layer": activation_layer}
        super().__init__()
        block = InvertedBottleneck(in_units, out_units, stride, branches, **factory_kwargs)
        self.add_module(f"block{stage_index}-{0}", block)
        for i in range(1, depth):
            block = Residual(out_units, out_units, branches, **factory_kwargs)
            self.add_module(f"block{stage_index}-{i}", block)


class BlockParams:
    def __init__(self, depths: Tuple[int, ...] | List[int],
                 widths: Tuple[int, ...] | List[int],
                 strides: Tuple[int, ...] | List[int],
                 stage_branches: Tuple[int, ...] | List[int]) -> None:
        self.depths = depths
        self.widths = widths
        self.strides = strides
        self.stage_branches = stage_branches

    @classmethod
    def from_init_params(cls, depth: int,
                         w_0: int,
                         w_a: float,
                         w_m: float,
                         branches: int = 2) -> "BlockParams":
        QUANT = 8
        STRIDE = 2

        if w_a < 0 or w_0 <= 0 or w_m <= 1 or w_0 % 8 != 0:
            raise ValueError("Invalid RegNeBt settings")

        # Compute the block widths. Each stage has one unique block width
        widths_cont = np.arange(depth, dtype=np.float32) * w_a + w_0
        block_capacity = np.round(np.log(widths_cont / w_0) / math.log(w_m))
        block_widths = (np.round(w_0 * w_m ** block_capacity / QUANT) * QUANT).astype(np.int32).tolist()

        num_stages = len(set(block_widths))

        # Convert to per stage parameters
        split_helper = zip(
            block_widths + [0],
            [0] + block_widths,
            block_widths + [0],
            [0] + block_widths,
        )
        splits = [w != wp or r != rp for w, wp, r, rp in split_helper]

        stage_widths = [w for w, t in zip(block_widths, splits[:-1]) if t]
        stage_depths = np.diff(np.array([d for d, t in enumerate(splits) if t], dtype=np.float32)).astype(np.int32).tolist()

        strides = [1 if i == 0 else STRIDE for i in range(num_stages)]

        stage_branches = [branches] * num_stages

        stage_widths = cls._adjust_widths(stage_widths, stage_branches)

        return cls(
            stage_depths,
            stage_widths,
            strides,
            stage_branches
        )

    def get_expanded_params(self):
        return zip(self.widths, self.strides, self.depths, self.stage_branches)

    @staticmethod
    def _adjust_widths(stage_widths: List[int],
                       stage_branches: List[int]) -> List[int]:
        return [_make_divisible(width, branches)
                for width, branches in zip(stage_widths, stage_branches)]


class RegNeBt(nn.Module):
    def __init__(self, block_params: BlockParams,
                 num_classes: int = 1000,
                 stem_width: int = 32,
                 conv_layer: Callable[..., nn.Module] | None = None,
                 norm_layer: Callable[..., nn.Module] | None = None,
                 activation_layer: Callable[..., nn.Module] | None = None) -> None:
        if conv_layer is None:
            conv_layer = partial(nn.Conv2d, bias=False)
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, momentum=0.01)
        if activation_layer is None:
            activation_layer = nn.SiLU
        factory_kwargs = {"conv_layer": conv_layer, "norm_layer": norm_layer, "activation_layer": activation_layer}
        super().__init__()
        _log_api_usage_once(self)

        # Ad hoc stem
        self.stem = SimpleStemIn(3, stem_width, stride=1, **factory_kwargs)

        current_width = stem_width
        blocks = []
        for i, (width_out, stride, depth, branches) in enumerate(block_params.get_expanded_params()):
            blocks.append((
                f"block{i + 1}",
                AnyStage(current_width, width_out, stride, branches, depth, **factory_kwargs)
            ))
            current_width = width_out

        self.trunk_output = nn.Sequential(OrderedDict(blocks))
        self.nonlinear = nn.SiLU()

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        
        self.fc = nn.Linear(in_features=current_width, out_features=num_classes)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.LayerNorm, nn.SyncBatchNorm)):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: Tensor) -> Tensor:
        x = self.stem(x)
        x = self.trunk_output(x)
        x = self.nonlinear(x)

        x = self.avgpool(x)
        x = x.flatten(start_dim=1)
        x = self.fc(x)

        return x


def _regnebt(
    block_params: BlockParams,
    **kwargs: Any
) -> RegNeBt:
    norm_layer = kwargs.pop("norm_layer", partial(nn.BatchNorm2d, momentum=0.01))
    model = RegNeBt(block_params, norm_layer=norm_layer, **kwargs)
    return model

@register_model()
def regnebt_B0(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=22, w_0=24, w_a=24.48, w_m=2.54, branches=2)
    return _regnebt(params, **kwargs)


@register_model()
def regnebt_B1(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=16, w_0=56, w_a=35.73, w_m=2.28, branches=4)
    return _regnebt(params, **kwargs)


@register_model()
def regnebt_B2(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=18, w_0=80, w_a=34.01, w_m=2.25, branches=2)
    return _regnebt(params, **kwargs)


@register_model()
def regnebt_B3(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=25, w_0=88, w_a=26.31, w_m=2.25, branches=2)
    return _regnebt(params, **kwargs)


@register_model()
def regnebt_B4(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=23, w_0=80, w_a=49.56, w_m=2.88, branches=2)
    return _regnebt(params, **kwargs)


@register_model()
def regnebt_B5(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=22, w_0=216, w_a=55.59, w_m=2.1, branches=2)
    return _regnebt(params, **kwargs)


@register_model()
def regnebt_B6(**kwargs: Any) -> RegNeBt:
    params = BlockParams.from_init_params(depth=23, w_0=320, w_a=69.86, w_m=2.0, branches=2)
    return _regnebt(params, **kwargs)