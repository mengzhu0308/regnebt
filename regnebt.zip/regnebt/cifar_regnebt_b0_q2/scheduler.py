#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2023/5/31 9:01
@File:          scheduler.py
'''

from typing import Optional
import torch
from optimizer import _get_value

class Scheduler:
    def __init__(self,
                 schedule: Optional[dict[int, Optional[float]]] = None,
                 from_zero: bool = True) -> None:
        super().__init__()
        if schedule is not None:
            for k in schedule:
                if schedule[k] is None:
                    schedule[k] = 1.
            self.schedule = sorted(schedule.items())
        else:
            self.schedule = schedule
        self.from_zero = from_zero

    def __call__(self, step: torch.FloatTensor) -> float:
        raise NotImplementedError

class LinearInverseTime(Scheduler):
    def __init__(self, schedule={1562: None, 70 * 1562: 0.01}, from_zero=True):
        super().__init__(schedule=schedule, from_zero=from_zero)
        self.K = (1 / self.schedule[-1][1] - 1) / (self.schedule[-1][0] - self.schedule[0][0])

    def __call__(self, step):
        if self.schedule is None:
            return 1.

        '''
            当step < schedule[0][0]，输出从0线性均匀增加至1，
            当step ∈ [schedule[0][0], schedule[1][0]) 输出从1逆时间衰减至schedule[-1][1] / (1 + schedule[-1][1])
            当step >= schedule[1][0]，输出保持schedule[-1][1]不变
            '''
        schedule = torch.as_tensor(self.schedule, dtype=step.dtype, device=step.device)
        factor = torch.where(torch.lt(step, schedule[0, 0]),
                             step / schedule[0, 0] if self.from_zero else torch.ones_like(step),
                             torch.where(torch.lt(step, schedule[1, 0]),
                                         self._inverse_time_decay(step, schedule),
                                         schedule[-1, 1]))
        return _get_value(factor)

    def _inverse_time_decay(self, step, schedule):
        return 1 / (self.K * (step - schedule[0, 0]) + 1)

class LinearCosine(Scheduler):
    def __init__(self, schedule={1562: None, 70 * 1562: 0.01}, from_zero=True):
        super().__init__(schedule=schedule, from_zero=from_zero)

    def __call__(self, step):
        if self.schedule is None:
            return 1.

        '''
            当step < schedule[0][0]，输出从0线性均匀增加至1，
            当step ∈ [schedule[0][0], schedule[1][0]) 输出从1余弦衰减至schedule[-1][1] / (1 + schedule[-1][1])
            当step >= schedule[1][0]，输出保持schedule[-1][1] / (1 + schedule[-1][1])不变
            '''
        schedule = torch.as_tensor(self.schedule, dtype=step.dtype, device=step.device)
        factor = torch.where(torch.lt(step, schedule[0, 0]),
                             step / schedule[0, 0] if self.from_zero else torch.ones_like(step),
                             torch.where(torch.lt(step, schedule[1, 0]),
                                         self._cosine_decay(step, schedule),
                                         schedule[-1, 1] / (1 + schedule[-1, 1])))
        return _get_value(factor)

    def _cosine_decay(self, step, schedule):
        factor = (1 + torch.cos(
            (step - schedule[0, 0]) / (schedule[1, 0] - schedule[0, 0]) * torch.pi)) / 2
        return (factor + schedule[-1, 1]) / (1 + schedule[-1, 1])

class SineCosine(Scheduler):
    def __init__(self, schedule={1562: None, 70 * 1562: 0.01}, from_zero=True):
        super().__init__(schedule=schedule, from_zero=from_zero)

    def __call__(self, step):
        if self.schedule is None:
            return 1.

        '''
            当step < schedule[0][0]，输出从0正弦增加至1，
            当step ∈ [schedule[0][0], schedule[1][0]) 输出从1余弦衰减至schedule[-1][1] / (1 + schedule[-1][1])
            当step >= schedule[1][0]，输出保持schedule[-1][1] / (1 + schedule[-1][1])不变
            '''
        schedule = torch.as_tensor(self.schedule, dtype=step.dtype, device=step.device)
        factor = torch.where(torch.lt(step, schedule[0, 0]),
                             torch.sin(step / schedule[0, 0] * torch.pi / 2) if self.from_zero else torch.ones_like(step),
                             torch.where(torch.lt(step, schedule[1, 0]),
                                         self._cosine_decay(step, schedule),
                                         schedule[-1, 1] / (1 + schedule[-1, 1])))

        return _get_value(factor)

    def _cosine_decay(self, step, schedule):
        factor = (1 + torch.cos(
            (step - schedule[0, 0]) / (schedule[1, 0] - schedule[0, 0]) * torch.pi)) / 2
        return (factor + schedule[-1, 1]) / (1 + schedule[-1, 1])

class PiecewiseLiner(Scheduler):
    def __init__(self, schedule={1562: 1, 117900: 0.01}, from_zero=True):
        super().__init__(schedule=schedule, from_zero=from_zero)

    def __call__(self, step):
        if self.schedule is None:
            return 1.

        schedule = self.schedule
        if self.from_zero and self.schedule[0][0] != 0:
            schedule = [(0, 0.0)] + self.schedule
        schedule = torch.as_tensor(schedule, dtype=step.dtype, device=step.device)

        '''
            当step < schedule[0][0]，输出从0均匀增加至1，
            当step ∈ [schedule[0][0], schedule[1][0]) 输出从1均匀衰减至0.01
            当step >= schedule[1][0]，输出保持0.01不变
            '''
        x = (step * 0 + 1) * schedule[0, 1]
        for i in range(len(schedule)):
            step_begin = schedule[i, 0]
            x_begin = x
            if i != len(schedule) - 1:
                dx = schedule[i + 1, 1] - schedule[i, 1]
                dt = schedule[i + 1, 0] - schedule[i, 0]
                slope = 1.0 * dx / dt
                x = schedule[i, 1] + slope * (step - step_begin)
            else:
                x = (step * 0 + 1) * schedule[i, 1]
            x = torch.where(torch.ge(step, step_begin), x, x_begin)

        return _get_value(x)
