'''
@Author:        zm
@Date and Time: 2019/8/8 18:20
@File:          testhistory2X.py
'''

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def testhistory2png(hist, saved_dir='.', model_name='', dataset_name=''):
    val_loss = np.array(hist['val_loss'], dtype=np.float32)
    top1_err = np.array(hist['top1_err'], dtype=np.float32)
    top5_err = np.array(hist['top5_err'], dtype=np.float32)

    # Plot validation error values
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(top1_err, label="top-1 err.")
    ax.plot(top5_err, label="top-5 err.")
    ax.grid(True)
    ax.set(ylabel='err.', xlabel='epoch')
    fig.savefig(f'{saved_dir}/{model_name}_{dataset_name}_val_error.pdf')

    # Plot validation loss values
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(val_loss)
    ax.legend()
    ax.grid(True)
    ax.set(ylabel='loss', xlabel='epoch')
    fig.savefig(f'{saved_dir}/{model_name}_{dataset_name}_val_loss.pdf')

def testhistory2excel(hist, saved_dir='.', model_name='', dataset_name=''):
    val_loss = np.array(hist['val_loss'], dtype=np.float32)
    top1_err = np.array(hist['top1_err'], dtype=np.float32)
    top5_err = np.array(hist['top5_err'], dtype=np.float32)

    df = pd.DataFrame({"val_loss": val_loss, "top1_err": top1_err, "top5_err": top5_err})

    df.to_excel(f'{saved_dir}/{model_name}_{dataset_name}_val_hist.xlsx', sheet_name='History', index=False)

def testhistory2txt(hist, saved_dir='.', model_name='', dataset_name=''):
    val_loss = np.array(hist['val_loss'], dtype=np.float32)
    top1_err = np.array(hist['top1_err'], dtype=np.float32)
    top5_err = np.array(hist['top5_err'], dtype=np.float32)

    lines = []
    line = 'val_loss\ttop1_err\ttop5_err\n'
    lines.append(line)
    for i, l in enumerate(val_loss):
        line = f'{l:.5f}\t{top1_err[i]:.2f}\t{top5_err[i]:.2f}\n'
        lines.append(line)

    lines[-1] = lines[-1].strip()
    with open(f'{saved_dir}/{model_name}_{dataset_name}_val_hist.txt', 'w', encoding='utf-8') as f:
        f.writelines(lines)