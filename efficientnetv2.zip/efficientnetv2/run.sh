#!/bin/bash

source ~/anaconda3/etc/profile.d/conda.sh

conda activate pt
python cifar_efficientnetv2_s/train_cifar100.py cifar_efficientnetv2_s
conda deactivate
sleep 240s

conda activate pt
python cifar_efficientnetv2_m/train_cifar100.py cifar_efficientnetv2_m
conda deactivate
sleep 240s

sleep 240s
shutdown -P now
