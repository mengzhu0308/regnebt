'''
@Author:        ZM
@Date and Time: 2020/6/9 16:08
@File:          stat.py
'''

import os
import torch
from shufflenext import shufflenext_x0_5, shufflenext_x1_0
from fvcore.nn import FlopCountAnalysis

os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
device = torch.device('cpu')

model = shufflenext_x1_0(num_classes=20)
total = sum(param.numel() for param in model.parameters())
print(f'{total / 1e6:.3f} M')

model.eval()
with torch.no_grad():
    '''
    使用fvcore
    '''
    tensor = (torch.randn(1, 3, 520, 520),)
    flops = FlopCountAnalysis(model, tensor)
    print(f'Flops: {flops.total() / 1e9:.3f} G')