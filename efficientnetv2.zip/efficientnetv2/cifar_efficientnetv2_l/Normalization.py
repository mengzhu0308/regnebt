'''
@Author:        zm
@Date and Time: 2019/7/15 14:11
@File:          Normalization.py
'''

import numpy as np

class Normalization:
    def __init__(self, mean=None, std=None):
        super(Normalization, self).__init__()
        self.mean = mean or (0.5,)
        self.std = std or (0.5,)

        if len(self.mean) > 1:
            self.mean = np.array(self.mean, dtype=np.float32)[None, None, :]
            self.std = np.array(self.std, dtype=np.float32)[None, None, :]
        else:
            self.mean = np.array(self.mean[0], dtype=np.float32)
            self.std = np.array(self.std[0], dtype=np.float32)

    def __call__(self, image):
        '''
        :param image: ∈ [0, 1]
        :return: ∈ [-1, 1]
        '''
        image = image.astype(np.float32)
        image = (image - self.mean) / self.std

        return image