#! -*- coding:utf-8 -*-

'''
@Author:        ZM
@Date and Time: 2021/5/3 14:47
@File:          RandomRGB2HSV.py
'''

import numpy as np
from matplotlib.colors import rgb_to_hsv, hsv_to_rgb

def rand(a: float = 0., b: float = 1.):
    return np.random.rand() * (b - a) + a

class RandomRGB2HSV:
    def __init__(self, p: float = 0.5, hue: float = .1, sat: float = 1.5, val: float = 1.5) -> None:
        super(RandomRGB2HSV, self).__init__()
        self.p = p
        self.hue = hue
        self.sat = sat
        self.val = val

    def __call__(self, image: np.ndarray) -> np.ndarray:
        if np.random.random() < self.p:
            return image

        hue = rand(-self.hue, self.hue)
        sat = rand(1, self.sat) if rand() < .5 else 1 / rand(1, self.sat)
        val = rand(1, self.val) if rand() < .5 else 1 / rand(1, self.val)
        x = rgb_to_hsv(image)
        x[..., 0] += hue
        x[..., 0][x[..., 0] > 1] -= 1
        x[..., 0][x[..., 0] < 0] += 1
        x[..., 1] *= sat
        x[..., 2] *= val
        x[x > 1] = 1
        x[x < 0] = 0
        image_data = hsv_to_rgb(x)  # numpy array, 0 to 1

        return image_data